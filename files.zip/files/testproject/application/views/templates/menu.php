<div id="header-2">
    <div class="container">
        <div class="default-nav-wrapper col-md-12 col-xs-12"> 	
            <nav id="site-navigation" class="main-navigation" role="navigation">
                <div id="nav-container">	
                             </div>  
            </nav><!-- #site-navigation -->
        </div>		  
    </div>
</div>