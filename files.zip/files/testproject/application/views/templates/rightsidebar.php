<div class="col-lg-4 col-md-4 col-sm-4">
    <div class="row page-content-site">
        <div class="col-lg-12 col-md-12 col-sm-12">	
            <div class="h3">&nbsp;</div>
            <div class="row">
                <h3>Side Bar</h3>

            </div>         
        </div>
    </div>
</div>
</div>